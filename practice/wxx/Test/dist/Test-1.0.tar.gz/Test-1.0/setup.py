from distutils.core import setup

setup(name='Test', version='1.0', description='TestModule', author='wxx', py_modules='')